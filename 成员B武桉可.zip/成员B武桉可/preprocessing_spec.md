# 成员 B：预处理与数据交接说明

## 1. 本次数据范围与结果

输入为 BCI Competition IV Dataset 2a 的九个训练会话文件 A01T–A09T。未使用 E-session。

- 总 trial：2,592；每名受试者 288
- 每名受试者每类 72；全体每类 648
- 采样率：250 Hz
- EEG：22 通道；排除 3 个 EOG 通道
- 输出：`X=(2592,22,751)`、`y=(2592,)`、`subject_id=(2592,)`

## 2. 事件标记的实际解释

本批 GDF 文件中：
- `768`：trial 起点
- `769`：Left
- `770`：Right
- `771`：Feet
- `772`：Tongue

类别提示事件出现在 trial 起点之后约 2 秒。处理时将每个 768 与同一个 trial 内唯一的类别事件配对，Epoch 相对 768 提取 0.5–3.5 秒。若把类别提示事件作为 Epoch 起点，会造成约 2 秒的时间偏移。

## 3. 统一预处理

| 项目 | 设置 |
|---|---|
| 数据集 | BCI Competition IV Dataset 2a |
| 会话 | T |
| 采样率 | 250 Hz |
| EEG 通道 | 22 个 `EEG-*` 通道 |
| 排除通道 | EOG-left、EOG-central、EOG-right |
| 滤波 | 8–30 Hz 带通 |
| Epoch | trial 起点后 0.5–3.5 秒 |
| 标签 | Left=0、Right=1、Feet=2、Tongue=3 |

MNE 对 Epoch 两端采样点均包含，因此 250 Hz 下实际输出 751 个时间点。成员 C 的模型应使用相同长度，除非团队统一决定重新生成 750 点版本。

## 4. 质量检查结论

- X、y、subject_id trial 数量一致。
- 22 通道，四类标签齐全且平衡。
- 所有数据值均为有限值，没有 NaN/Inf。
- 通道级统计没有发现标准差低于 1e-12 V 的近乎平直通道。
- 统计振幅仅用于初步异常排查，不替代人工坏道判定。

## 5. 交接接口

`results/all_subjects_T.npz` 包含 `X`、`y`、`subject_id`。三者 trial 顺序一一对应。成员 C 可按 subject_id 做 LOSO 留一受试者测试。

## 6. 防止数据泄漏

成员 B 只负责固定滤波、Epoch 和数据组织，不拟合 CSP、标准化、特征选择等学习参数。所有此类步骤由成员 C 在每轮训练受试者上 fit，再应用到测试受试者。
