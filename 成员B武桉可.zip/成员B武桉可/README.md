# 成员 B 交付物：多受试者数据集构建与预处理

## 1. 本次真实数据处理结果

已使用上传的 A01T–A09T 九个 GDF 文件完成读取、预处理和质量检查。

| 项目 | 实际结果 |
|---|---:|
| 受试者 | 9（A01–A09） |
| 每人 trial | 288 |
| 总 trial | 2,592 |
| EEG 通道 | 22 |
| 采样率 | 250 Hz |
| 每个 Epoch 时间点 | 751 |
| 类别 | 4 类，每类 648 个 trial |
| NaN / Inf | 0 |
| 缺失类别 | 0 |

数据数组：
- `X.shape = (2592, 22, 751)`
- `y.shape = (2592,)`
- `subject_id.shape = (2592,)`

本次质量检查通过。通道级诊断中，所有通道数据均为有限值，没有发现标准差低于 `1e-12 V` 的近乎平直通道。振幅统计是异常排查线索，不等于完成了人工坏道判定。

## 2. 文件清单

- `src/data/multi_subject_data.py`：读取单名受试者 T-session GDF、多人合并、按 subject_id 筛选，输出统一的 `X / y / subject_id`。
- `src/data/data_quality_check.py`：数组质量检查、逐受试者 trial 统计、逐通道振幅/方差诊断。
- `results/all_subjects_T.npz`：本次实际处理得到的九人数据，可直接交给成员 C。
- `results/subject_statistics.csv`：逐受试者 trial 数量与类别分布。
- `results/channel_quality.csv`：逐受试者、逐通道数据质量描述。
- `results/data_quality_report.json`：总体质量检查结果。
- `docs/preprocessing_spec.md`：预处理与数据交接说明。
- `docs/preprocessing_metadata.json`：本次数据版本、事件、通道和预处理元数据。

## 3. 安装依赖

```bash
pip install mne numpy pandas scipy
```

## 4. 复现方式

将九个训练会话文件放在 `data/raw/` 下（程序会递归查找文件）：

```text
data/raw/
├── A01T.gdf
├── A02T.gdf
...
└── A09T.gdf
```

先处理 A01–A05：

```bash
python src/data/multi_subject_data.py --data-dir data/raw --subjects A01 A02 A03 A04 A05 --output results/A01_A05_data.npz
```

扩展到九名受试者：

```bash
python src/data/multi_subject_data.py --data-dir data/raw --subjects A01 A02 A03 A04 A05 A06 A07 A08 A09 --output results/all_subjects_T.npz
```

运行质量检查：

```bash
python src/data/data_quality_check.py --input results/all_subjects_T.npz --output results/subject_statistics.csv
```

该命令同时生成同目录下的 `channel_quality.csv`。

## 5. Python 接口（供成员 C 调用）

```python
import numpy as np

data = np.load("results/all_subjects_T.npz", allow_pickle=False)
X = data["X"]
y = data["y"]
subject_id = data["subject_id"]

print(X.shape)          # (2592, 22, 751)
print(y.shape)          # (2592,)
print(subject_id.shape) # (2592,)
```

也可以直接调用加载函数：

```python
from src.data.multi_subject_data import load_multiple_subjects

X, y, subject_id = load_multiple_subjects(
    data_dir="data/raw",
    subject_ids=[f"A{i:02d}" for i in range(1, 10)],
)
```

成员 C 可使用 `subject_id` 实现九轮 LOSO。筛选或打乱数据时，X、y、subject_id 必须同步操作。

## 6. 预处理与事件解释

- 数据集：BCI Competition IV Dataset 2a
- 会话：T（训练会话）
- 采样率：250 Hz；程序核对采样率，不自动重采样
- EEG 通道：22 个 `EEG-*` 通道
- 排除通道：`EOG-left`、`EOG-central`、`EOG-right`
- 带通滤波：8–30 Hz
- Epoch：相对 trial 起点 0.5–3.5 秒
- trial 起点事件：768
- 类别提示事件：769、770、771、772
- 标签：Left=0、Right=1、Feet=2、Tongue=3

**事件处理特别说明：** 本批文件中，768 是 trial 起点；769–772 是约 2 秒后出现的类别提示。程序将每个 768 与同一 trial 内唯一的类别提示配对，并把 Epoch 锚定在 768 上。不能把 769–772 直接当作 Epoch 起点，否则 Epoch 会整体错后约 2 秒。

MNE 的 Epochs 在 `tmin=0.5` 和 `tmax=3.5` 两端都包含采样点，因此 250 Hz 下输出 751 个时间点。这是本次真实输出形状，成员 C 的模型输入必须按 751 点适配，或由团队明确决定统一改成半开区间 750 点并重新生成数据。

## 7. 数据质量检查范围

本次已检查：
- X/y/subject_id 维度与 trial 数量是否对齐
- 通道数是否为 22
- 标签是否只包含 0、1、2、3
- 是否存在 NaN 或 Inf
- 每名受试者总 trial 数和四类分布
- 每名受试者、每个通道的标准差、平均绝对振幅、最大绝对振幅
- 是否存在近乎平直通道（标准差低于 1e-12 V）

程序不会自动删除 trial 或通道。当前检查未发现平直通道，但不能仅凭统计量断言所有通道都没有生理或采集质量问题。

## 8. 与成员 C 的边界

成员 B 交付统一格式的数据，不在本模块中拟合 CSP、LDA、标准化器或特征选择器。成员 C 必须在每一轮 LOSO 的训练受试者上拟合所有有学习参数的步骤，再应用到完全留出的测试受试者，避免信息泄漏。

## 9. 交接给团队前的提醒

1. 本次输入是九名受试者的 T-session；E-session 没有纳入。
2. 预处理后的 NPZ 是真实处理结果，不是示例数据。
3. 当前 Epoch 输出是 751 点；请成员 C 确认模型使用此输入长度。
4. 原始 GDF 不应提交到 GitHub 仓库；可在本地按 README 路径存放。
