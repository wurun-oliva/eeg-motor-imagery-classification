# -*- coding: utf-8 -*-
"""
成员 C · LOSO（Leave-One-Subject-Out）跨用户评估

做法：对 subjects 里的每名受试者轮一次 —— 把他当"考官没见过的新人"，
其余所有人合并训练一个模型，然后只对这一人做预测；统计逐受试者指标。

红线：
  1) 测试受试者绝不进入 fit（训练、CSP、LDA 都只用训练受试者数据）；
  2) 测试受试者只做 pipeline.predict / transform；
  3) 结果是逐受试者 + 均值±标准差（禁止只报总体平均）。

用法示例：
  python src/evaluation/loso_evaluation.py --subjects A01 A02 A03
  python src/evaluation/loso_evaluation.py --subjects A01 A02 A03 --out results/loso_smoke.csv
"""
import argparse
import csv
import sys
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (accuracy_score, f1_score, cohen_kappa_score,
                             confusion_matrix, ConfusionMatrixDisplay)

# 让 import 能找到同仓库的 src 包（从项目根目录运行时直接可用）
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from src.models.cross_subject_model import make_pipe  # noqa: E402
from src.data.data_loader import load_trials        # noqa: E402（成员B正式加载器胶水）

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False


def run_loso(subjects, data_dir, n_components=4, seed=42,
             reg=None, log=True, cov_est="concat"):
    """执行 LOSO，返回 (rows, summary)。rows 每行 = 一名测试受试者。"""
    # ---- 把每个受试者读进来，各自独立成组，互不干扰 ----
    by_subject = {}
    for subj in subjects:
        path = f"{data_dir}/{subj}T.gdf"
        X, y, _sid = load_trials(path, subject_id=subj)
        by_subject[subj] = (X, y)

    rows = []
    cms = []
    for test_subj in subjects:
        X_test, y_test = by_subject[test_subj]
        # ---- 训练受试者 = 除测试者以外的所有人 ----
        train_subjects = [s for s in subjects if s != test_subj]
        X_tr = np.concatenate([by_subject[s][0] for s in train_subjects], axis=0)
        y_tr = np.concatenate([by_subject[s][1] for s in train_subjects], axis=0)

        pipe = make_pipe(n_components=n_components, reg=reg,
                         log=log, cov_est=cov_est)
        pipe.fit(X_tr, y_tr)             # 只对"训练受试者"拟合
        y_pred = pipe.predict(X_test)     # 测试者只 predict，绝不 fit

        acc = accuracy_score(y_test, y_pred)
        mf1 = f1_score(y_test, y_pred, average="macro")
        kap = cohen_kappa_score(y_test, y_pred)
        cm = confusion_matrix(y_test, y_pred, labels=[0, 1, 2, 3])
        cms.append(cm)

        rows.append({
            "test_subject": test_subj,
            "n_test_trials": len(y_test),
            "n_train_subjects": len(train_subjects),
            "train_subjects": "+".join(train_subjects),
            "accuracy": acc,
            "macro_f1": mf1,
            "cohen_kappa": kap,
            "n_components": n_components,
            "reg": "None" if reg is None else str(reg),
            "log": log,
            "cov_est": cov_est,
            "seed": seed,
            "model": "CSP+LDA",
            "source": "T session",
        })
        print(f"[{test_subj}] Acc={acc:.2%}  MacroF1={mf1:.3f}  "
              f"Kappa={kap:.3f}  (train={'+'.join(train_subjects)})")

    accs = np.array([r["accuracy"] for r in rows])
    mf1s = np.array([r["macro_f1"] for r in rows])
    kaps = np.array([r["cohen_kappa"] for r in rows])
    summary = {
        "n_subjects": len(subjects),
        "acc_mean": float(accs.mean()), "acc_std": float(accs.std()),
        "mf1_mean": float(mf1s.mean()), "mf1_std": float(mf1s.std()),
        "kappa_mean": float(kaps.mean()), "kappa_std": float(kaps.std()),
    }
    return rows, summary, cms


def save_csv(rows, summary, out_csv):
    fieldnames = ["test_subject", "n_test_trials", "n_train_subjects",
                  "train_subjects", "accuracy", "macro_f1", "cohen_kappa",
                  "n_components", "reg", "log", "cov_est", "seed",
                  "model", "source"]
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)
        w.writerow({"test_subject": "AVERAGE",
                    "accuracy": summary["acc_mean"],
                    "macro_f1": summary["mf1_mean"],
                    "cohen_kappa": summary["kappa_mean"],
                    "n_components": rows[0]["n_components"],
                    "reg": rows[0]["reg"], "log": rows[0]["log"],
                    "cov_est": rows[0]["cov_est"], "seed": rows[0]["seed"],
                    "model": rows[0]["model"], "source": rows[0]["source"]})
    print(f"\n结果表已保存: {out_csv}")
    print(f"LOSO 总体：Acc = {summary['acc_mean']:.2%} ± {summary['acc_std']:.2%} | "
          f"MacroF1 = {summary['mf1_mean']:.3f} ± {summary['mf1_std']:.3f} | "
          f"Kappa = {summary['kappa_mean']:.3f} ± {summary['kappa_std']:.3f}")


def plot_confusion(cms, subjects, out_png):
    """画汇总（行归一化）混淆矩阵。"""
    labels = ["左手", "右手", "双脚", "舌头"]
    total = np.sum(cms, axis=0)
    norm = total.astype(float) / total.sum(axis=1, keepdims=True)

    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    disp = ConfusionMatrixDisplay(confusion_matrix=norm, display_labels=labels)
    disp.plot(ax=ax, cmap="Blues", values_format=".2f", colorbar=True)
    ax.set_title(f"LOSO 汇总混淆矩阵（行归一化，n={len(subjects)}）")
    plt.tight_layout()
    plt.savefig(out_png, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"混淆矩阵图已保存: {out_png}")


def main():
    ap = argparse.ArgumentParser(description="LOSO 跨用户评估")
    ap.add_argument("--subjects", nargs="+", required=True,
                    help="例如: A01 A02 A03")
    ap.add_argument("--data-dir", default="data/BCICIV_2a_gdf")
    ap.add_argument("--out", default="results/loso_results.csv")
    ap.add_argument("--n-components", type=int, default=4)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    rows, summary, cms = run_loso(
        args.subjects, args.data_dir,
        n_components=args.n_components, seed=args.seed)
    save_csv(rows, summary, args.out)
    plot_confusion(cms, args.subjects,
                   os.path.splitext(args.out)[0] + "_confusion.png")


if __name__ == "__main__":
    main()
