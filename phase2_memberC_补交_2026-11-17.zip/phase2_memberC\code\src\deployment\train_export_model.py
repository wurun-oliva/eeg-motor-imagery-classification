# -*- coding: utf-8 -*-
"""训练最终部署模型（全部 9 名受试者 T-session 合并训练）并导出 joblib。

用途：给成员A 的实时数据接口提供可直接 predict 的模型文件。

口径（与已验收优化结论一致）：
  - CSP 成分数 n_components=6（Loso 扫描最优）
  - reg=None, log=True, cov_est="concat"
  - standardize=False（优化结论：不引入标准化）
  - 数据侧：22 通道（顺序= DEFAULT_EEG_CHANNELS）、250Hz、8-30Hz IIR、epoch cue后0.5-3.5s、单位 V

注意：这是“部署模型”（用全部 9 人训练，最大化泛化），不做 LOSO 公平评估；
离线可报告的无泄漏指标来自 LOSO n=6 管线（约 41.98%）。
"""
import argparse
import os
import sys

import numpy as np
import joblib

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from src.models.cross_subject_model import make_pipe  # noqa: E402
from src.data.data_loader import load_trials           # noqa: E402

SUBJECTS = [f"A0{i}" for i in range(1, 10)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data/BCICIV_2a_gdf")
    ap.add_argument("--n-components", type=int, default=6)
    ap.add_argument("--out",
                    default="outputs/phase2_memberC/bci2a_csp_lda_n6_all9.joblib")
    args = ap.parse_args()

    Xs, ys = [], []
    for s in SUBJECTS:
        path = os.path.join(args.data_dir, f"{s}T.gdf")
        X, y, _ = load_trials(path, subject_id=s)
        Xs.append(X)
        ys.append(y)
        print(f"  {s}: {X.shape}  classes={np.bincount(y.astype(int))}")
    X_all = np.concatenate(Xs, axis=0)   # (2592, 22, 751)
    y_all = np.concatenate(ys, axis=0)

    pipe = make_pipe(n_components=args.n_components, reg=None,
                     log=True, cov_est="concat", standardize=False)
    print("正在拟合（全 9 人合并）：", X_all.shape)
    pipe.fit(X_all, y_all)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    joblib.dump(pipe, args.out)
    print(f"模型已导出: {args.out}")

    # 自检：单个 trial 也能预测
    X0 = Xs[0][:5]
    pred = pipe.predict(X0)
    proba = pipe.predict_proba(X0)
    print("自检 predict(5 trials) ->", pred.tolist())
    print("自检 proba shape ->", proba.shape, "第0行=", np.round(proba[0], 3))


if __name__ == "__main__":
    main()
