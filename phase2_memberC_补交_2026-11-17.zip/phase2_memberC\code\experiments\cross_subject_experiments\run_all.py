# -*- coding: utf-8 -*-
"""成员C · 一键可重复运行 + 验收断言（规范 §5 可复现 / 验收清单 ①②③）

用法：
  python experiments/cross_subject_experiments/run_all.py            # 只做验收/对账断言（不重跑，默认）
  python experiments/cross_subject_experiments/run_all.py --rerun     # 清表→按序重跑 4 实验→对账断言

验收断言（默认模式几乎即时，基于现有产物）：
  ① 无泄漏：loso_results_22ch.csv 每行 test_subject 不在 train_subjects，且 len(train)=8
  ② 独立结果：test_subject 全覆盖 A01..A09 且无重复
  ③ 可重复/幂等：model_comparison.csv 恰好 72 行 = csp_components 36 + standardization 18 + frequency_band 18；
     frequency_band 的 8-30Hz 档与 csp_components 的 n=6 逐位一致（自检）。
"""
import argparse
import csv
import os
import re
import subprocess
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "results"
SUBJECTS = [f"A0{i}" for i in range(1, 10)]

FIELDNAMES = ["experiment", "n_components", "test_subject", "n_test_trials",
              "accuracy", "macro_f1", "cohen_kappa", "model", "source",
              "data_version", "note"]


def read_csv(path, fieldnames):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def check_leakage(loso_csv):
    rows = read_csv(loso_csv, None)
    # 仅取受试者行：跳过 AVERAGE 汇总行
    rows = [r for r in rows if re.fullmatch(r"A0[1-9]", r["test_subject"])]
    errs = []
    if len(rows) != 9:
        errs.append(f"loso 结果应有 9 行，实际 {len(rows)}")
    tests = [r["test_subject"] for r in rows]
    if sorted(tests) != SUBJECTS:
        errs.append(f"test_subject 覆盖不全: {tests}")
    for r in rows:
        test = r["test_subject"]
        train = r["train_subjects"]
        n = r["n_train_subjects"]
        names = train.split("+") if train.strip() else []
        if test in names:
            errs.append(f"{test}: 测试者在训练名单中出现！train={train}")
        if str(len(names)) != n:
            errs.append(f"{test}: n_train_subjects={n} 与 train_subjects 实际 {len(names)} 不符")
        if len(set(names)) != len(names):
            errs.append(f"{test}: 训练名单重复 {names}")
    return errs


def check_model_comparison(comp_csv):
    rows = read_csv(comp_csv, FIELDNAMES)
    errs = []
    counts = {}
    for r in rows:
        counts[r["experiment"]] = counts.get(r["experiment"], 0) + 1
    expect = {"csp_components": 36, "standardization": 18, "frequency_band": 18}
    for k, v in expect.items():
        if counts.get(k, 0) != v:
            errs.append(f"{k}: 期望 {v} 行，实际 {counts.get(k, 0)}")
    if len(rows) != sum(expect.values()):
        errs.append(f"总行数期望 {sum(expect.values())}，实际 {len(rows)}")

    # 频带自检：frequency_band 的 8-30Hz 应等于 csp_components 的 n=6，逐受试者一致
    band830 = {r["test_subject"]: float(r["accuracy"])
               for r in rows if r["experiment"] == "frequency_band" and "8-30" in r["note"][:12]}
    n6 = {r["test_subject"]: float(r["accuracy"])
          for r in rows if r["experiment"] == "csp_components" and r["n_components"] == "6"}
    if set(band830) != set(n6):
        errs.append("frequency_band 8-30 vs csp_components n=6 受试者集合不一致")
    for s in band830:
        if s in n6 and not np.isclose(band830[s], n6[s], atol=1e-6):
            errs.append(f"{s}: 自检不一致 band830={band830[s]:.4f} vs n6={n6[s]:.4f}")
    return errs


def dump_table(comp_csv):
    """清空对比表（只保留表头），供 --rerun 幂等重跑。"""
    with open(comp_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDNAMES)
        w.writeheader()


def rerun_all():
    # 注意：loso_evaluation 的 --subjects/--out 必填，需显式传全 9 人并指向 22ch 表；
    # csp_components_scan 覆写主表，standardization/band 追加，故先清表保证幂等。
    scripts = [
        [sys.executable, "src/evaluation/loso_evaluation.py",
         "--subjects", *[f"A0{i}" for i in range(1, 10)],
         "--out", "results/loso_results_22ch.csv"],
        [sys.executable, "experiments/cross_subject_experiments/csp_components_scan.py"],
        [sys.executable, "experiments/cross_subject_experiments/standardization_scan_22ch.py"],
        [sys.executable, "experiments/cross_subject_experiments/band_scan_22ch.py"],
    ]
    comp_csv = RESULTS / "model_comparison.csv"
    dump_table(comp_csv)  # 幂等：先清表，避免重复行
    for s in scripts:
        print(f"==> 运行 {' '.join(s)}")
        r = subprocess.run(s, cwd=str(ROOT))
        if r.returncode != 0:
            raise SystemExit(f"{s[1]} 运行失败 rc={r.returncode}")
    print("=> 全部重跑完成，开始对账断言")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rerun", action="store_true", help="清表并重新跑 4 个实验（约需数分钟）")
    args = ap.parse_args()

    if args.rerun:
        rerun_all()

    loso_csv = RESULTS / "loso_results_22ch.csv"
    comp_csv = RESULTS / "model_comparison.csv"
    errs = check_leakage(loso_csv)
    errs += check_model_comparison(comp_csv)

    print("=" * 64)
    if errs:
        print("验收断言：未通过")
        for e in errs:
            print("  - " + e)
        sys.exit(1)
    print("验收断言：全部通过")
    print("  ① 无泄漏：每轮测试受试者不在训练名单，训练人数=8")
    print("  ② 独立结果：A01..A09 每名测试者各有一行，无遗漏无重复")
    print("  ③ 对账：model_comparison.csv 恰 72 行（36/18/18）且频带 8-30Hz 与成分数 n=6 逐位自检一致")
    print("=" * 64)


if __name__ == "__main__":
    main()
