# -*- coding: utf-8 -*-
"""
成员C · 优化实验①：CSP 成分数 n_components 对 LOSO 的影响（2/4/6/8）

纪律：一次只改一个变量——这里只动 CSP 的 n_components，其余参数与基线
完全一致（8-30Hz、CSP log=True cov_est=concat、LDA、T session、LOSO 轮换规则相同）。
数据只加载一次，四个设置复用同一份已加载数据，避免重复读盘。

产物：
  results/model_comparison.csv             （主对比表：每行=某受试者×某设置）
  results/csp_components_summary.csv       （受试者×设置 矩阵 + 平均/±std）
  results/csp_components_mean_plot.png     （各设置平均准确率 ± std 对比柱状图）
"""
import csv
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, f1_score, cohen_kappa_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from src.models.cross_subject_model import make_pipe      # noqa: E402
from src.data.data_loader import load_trials          # noqa: E402（成员B正式加载器胶水）

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SUBJECTS = [f"A0{i}" for i in range(1, 10)]
DATA_DIR = "data/BCICIV_2a_gdf"
CONFIGS = [2, 4, 6, 8]          # 要对比的 n_components
EXPERIMENT = "csp_components"


def load_all():
    """把 9 名受试者各读一次，缓存为 {subj: (X, y)}。"""
    by = {}
    for s in SUBJECTS:
        X, y, _sid = load_trials(f"{DATA_DIR}/{s}T.gdf", subject_id=s)
        by[s] = (X, y)
    return by


def loso_rows(by, n_components):
    """对给定 n_components 跑完整 LOSO，返回逐受试者 rows。"""
    rows = []
    for test in SUBJECTS:
        train = [s for s in SUBJECTS if s != test]
        Xtr = np.concatenate([by[s][0] for s in train], axis=0)
        ytr = np.concatenate([by[s][1] for s in train], axis=0)
        Xte, yte = by[test]

        pipe = make_pipe(n_components=n_components)   # 其余参数与基线一致
        pipe.fit(Xtr, ytr)                             # 只对训练受试者拟合
        yp = pipe.predict(Xte)                         # 测试者只 predict

        rows.append({
            "experiment": EXPERIMENT,
            "n_components": n_components,
            "test_subject": test,
            "n_test_trials": len(yte),
            "accuracy": accuracy_score(yte, yp),
            "macro_f1": f1_score(yte, yp, average="macro"),
            "cohen_kappa": cohen_kappa_score(yte, yp),
            "model": "CSP+LDA",
            "source": "T session",
            "data_version": "BCICIV_2a_gdf A01T-A09T",
            "note": "22ch(剔除EOG)，只改 n_components，其余锁死",
        })
        print(f"  n={n_components:>2} | test {test}: "
              f"Acc={rows[-1]['accuracy']:.2%} "
              f"F1={rows[-1]['macro_f1']:.3f} "
              f"Kappa={rows[-1]['cohen_kappa']:.3f}")
    return rows


def main():
    print("=" * 72)
    print(f"优化实验①：CSP 成分数 n_components in {CONFIGS}（LOSO 9 人）")
    print("=" * 72)
    by = load_all()

    all_rows = []
    summary = {subj: {} for subj in SUBJECTS}   # summary[subj][n] = acc
    for n_comp in CONFIGS:
        print(f"--- n_components = {n_comp} ---")
        rows = loso_rows(by, n_comp)
        all_rows.extend(rows)
        for r in rows:
            summary[r["test_subject"]][n_comp] = r["accuracy"]

    # ---- 保存主对比表 model_comparison.csv ----
    fieldnames = ["experiment", "n_components", "test_subject", "n_test_trials",
                  "accuracy", "macro_f1", "cohen_kappa", "model", "source",
                  "data_version", "note"]
    out_csv = os.path.join(os.path.dirname(__file__), "..", "..", "results",
                           "model_comparison.csv")
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(all_rows)
    print(f"\n主对比表已保存: {out_csv}（{len(all_rows)} 行）")

    # ---- 逐设置汇总 + 摘要表 ----
    means, stds = {}, {}
    for n_comp in CONFIGS:
        accs = [summary[s][n_comp] for s in SUBJECTS]
        means[n_comp] = float(np.mean(accs))
        stds[n_comp] = float(np.std(accs))
        print(f"n_components={n_comp:>2}: LOSO Acc = {means[n_comp]:.2%} ± {stds[n_comp]:.2%}")

    best = max(CONFIGS, key=lambda n: means[n])
    print("-" * 72)
    print(f"结论：n_components={best} 平均最高")
    print("注意：只看平均可能被个体差异掩盖，详见逐受试者对比例图。")

    sum_csv = os.path.join(os.path.dirname(__file__), "..", "..", "results",
                           "csp_components_summary.csv")
    with open(sum_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["test_subject"] + [f"n{n}" for n in CONFIGS])
        for s in SUBJECTS:
            w.writerow([s] + [f"{summary[s][n]:.4f}" for n in CONFIGS])
        w.writerow(["MEAN"] + [f"{means[n]:.4f}" for n in CONFIGS])
        w.writerow(["STD"] + [f"{stds[n]:.4f}" for n in CONFIGS])
    print(f"逐受试者摘要表已保存: {sum_csv}")

    # ---- 图1：平均准确率 ± std ----
    x = np.arange(len(CONFIGS))
    fig, ax = plt.subplots(figsize=(8, 5))
    vals = [means[n] for n in CONFIGS]
    errs = [stds[n] for n in CONFIGS]
    bars = ax.bar(x, vals, yerr=errs, capsize=6,
                  color=["#c0504d", "#4C72B0", "#DD8452", "#55A868"])
    ax.axhline(0.25, color="gray", ls=":", lw=1, label="随机基线 25%")
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.008, f"{v:.1%}",
                ha="center", va="bottom")
    ax.set_xticks(x)
    ax.set_xticklabels([f"{n}" for n in CONFIGS])
    ax.set_xlabel("CSP 成分数 n_components")
    ax.set_ylabel("LOSO 平均准确率")
    ax.set_ylim(0, 0.75)
    ax.set_title("优化①：CSP 成分数对跨用户(9人 LOSO)平均准确率的影响")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    png1 = os.path.join(os.path.dirname(__file__), "..", "..", "results",
                        "csp_components_mean_plot.png")
    plt.savefig(png1, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"平均对比图已保存: {png1}")

    # ---- 图2：逐受试者线图（看个体差异而非只看平均）----
    fig2, ax2 = plt.subplots(figsize=(9.5, 6))
    colors = plt.cm.tab10(np.linspace(0, 1, len(SUBJECTS)))
    for i, s in enumerate(SUBJECTS):
        ax2.plot(CONFIGS, [summary[s][n] for n in CONFIGS],
                 marker="o", label=s, color=colors[i], linewidth=1.3)
    ax2.axhline(0.25, color="gray", ls=":", lw=1, label="随机基线 25%")
    ax2.set_xticks(CONFIGS)
    ax2.set_xlabel("CSP 成分数 n_components")
    ax2.set_ylabel("LOSO 准确率（该受试者当测试者）")
    ax2.set_ylim(0, 0.8)
    ax2.set_title("优化①：各受试者在不同 CSP 成分数下的 LOSO 准确率")
    ax2.legend(ncol=3, fontsize=8, loc="upper right")
    ax2.grid(alpha=0.3)
    plt.tight_layout()
    png2 = os.path.join(os.path.dirname(__file__), "..", "..", "results",
                        "csp_components_per_subject.png")
    plt.savefig(png2, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"逐受试者对比例图已保存: {png2}")


if __name__ == "__main__":
    main()
