# -*- coding: utf-8 -*-
"""成员C 数据加载胶水层：对外接口保持 load_trials(path, subject_id, l_freq, h_freq) -> (X, y, subject_id)

内部委托成员B 官方修正版 multi_subject_data.load_subject（2026-11-17 已按修正单落实）：
  · 锚点=类别 cue(769-772)，epoch 0.5-3.5 s（anchor="cue"，与团队验收口径一致）
  · 22 个 EEG-* 通道（剔除 EOG 3 个），按 DEFAULT_EEG_CHANNELS 显式固定顺序
  · 采样率校验 250 Hz；IIR 带通（默认 8-30 Hz）
  · 标签 Left=0/Right=1/Feet=2/Tongue=3

历史：成员B 原版多锚定 768(试次起点) 把窗口前置 2 s（768->cue 恒 500 样本=2.000s，A01 实测
288/288），精度 39.6%->29.1%；已由 B 按修正单改为 cue 锚点。vs 旧 cue 对齐版逐位一致
（max|Δ|=0.0，9 人验收通过）。

成员B 的 load_subject 返回 6 元组 (X, y, ids, channels, sfreq, metadata)；
本胶水按阶段契约降为 (X, y, subject_id) 三件套，实验脚本无需改动。
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from src.data.multi_subject_data import load_subject

# 22 头皮 EEG 固定顺序（gdf 原生顺序，剔除 EOG）；与临时加载器约定一致。
DEFAULT_EEG_CHANNELS = [
    "EEG-Fz", "EEG-0", "EEG-1", "EEG-2", "EEG-3", "EEG-4", "EEG-5",
    "EEG-C3", "EEG-6", "EEG-Cz", "EEG-7", "EEG-C4",
    "EEG-8", "EEG-9", "EEG-10", "EEG-11", "EEG-12", "EEG-13", "EEG-14",
    "EEG-Pz", "EEG-15", "EEG-16",
]
assert len(DEFAULT_EEG_CHANNELS) == 22


class ChannelOrderChangedError(ValueError):
    """B 加载器返回的通道顺序与固定顺序不一致时抛出，防止静默换序。"""


def load_trials(gdf_path, subject_id, l_freq=8.0, h_freq=30.0, tmin=0.5, tmax=3.5):
    """加载单个受试者，返回 (X, y, subject_id) 三件套（契约）。

    gdf_path 传文件路径或目录：
      - 传文件路径：取父目录为 data_dir，subject_id 必须与文件名 Axx 一致；
      - 传目录：data_dir=gdf_path，按 subject_id 自动定位 AxxT.gdf。
    """
    p = Path(str(gdf_path))
    if p.is_file():
        data_dir = str(p.parent)
    else:
        data_dir = str(p)

    X, y, ids, channels, sfreq, metadata = load_subject(
        data_dir,
        subject_id,
        l_freq=l_freq,
        h_freq=h_freq,
        tmin=tmin,
        tmax=tmax,
        expected_sfreq=250.0,
        expected_eeg_channels=22,
        channel_names=DEFAULT_EEG_CHANNELS,
        anchor="cue",
        verbose="ERROR",
    )
    if list(channels) != DEFAULT_EEG_CHANNELS:
        raise ChannelOrderChangedError(
            f"{subject_id}: 通道顺序变了 {list(channels)} != {DEFAULT_EEG_CHANNELS}"
        )

    # 契约三件套：X 转 float32 顺带保持维度、y 为 int64、subject_id 对齐。
    X = np.asarray(X, dtype=np.float32)
    y = np.asarray(y, dtype=np.int64)
    return X, y, np.asarray(ids, dtype="<U3")
