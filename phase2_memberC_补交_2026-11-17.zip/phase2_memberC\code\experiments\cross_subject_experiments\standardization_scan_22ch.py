# -*- coding: utf-8 -*-
"""
成员C · 优化实验②复核@22ch：仅训练集拟合的标准化（StandardScaler，Z-Score）

纪律：一次只改一个变量——这里只加/不加 StandardScaler，其余与基线完全一致
（n_components=6、8-30Hz、CSP log=True cov_est=concat、LDA、T session、LOSO 规则）。

复核背景：2026-11-12 按规范 §4.2 改为 22ch（剔除 EOG、顺序固定）；
n_components 随新基准更新为 6（成分数扫描 @22ch 最优），其余锁定不变。

红线要点：scaler 只在训练受试者上 fit（sklearn Pipeline 天然如此：
fit 时学均值和方差，predict 时对测试者只 transform）。
这不同于常见的"全体数据做标准化"——后者等于用到了考卷答案，是泄漏。

产物（追加进 22ch 主对比表）：
  results/model_comparison.csv   （新增 experiment=standardization 的 18 行）
  results/standardization_summary.csv
  results/standardization_plot.png
（25ch 时代旧版脚本 standardization_scan.py 保留不动，产物已在 _archive_25ch/）
"""
import csv
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, f1_score, cohen_kappa_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from src.models.cross_subject_model import make_pipe      # noqa: E402
from src.data.data_loader import load_trials          # noqa: E402（成员B正式加载器胶水）

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SUBJECTS = [f"A0{i}" for i in range(1, 10)]
DATA_DIR = "data/BCICIV_2a_gdf"
N_COMPONENTS = 6          # 22ch 新基准（成分数扫描@22ch 最优），只评估标准化这一个旋钮
CONFIGS = [              # (label, standardize)
    ("no_standardize", False),
    ("standardize", True),
]
EXPERIMENT = "standardization"
ROOT = os.path.join(os.path.dirname(__file__), "..", "..")

FIELDNAMES = ["experiment", "n_components", "test_subject", "n_test_trials",
              "accuracy", "macro_f1", "cohen_kappa", "model", "source",
              "data_version", "note"]


def load_all():
    by = {}
    for s in SUBJECTS:
        X, y, _sid = load_trials(f"{DATA_DIR}/{s}T.gdf", subject_id=s)
        by[s] = (X, y)
    return by


def loso_rows(by, standardize):
    rows = []
    for test in SUBJECTS:
        train = [s for s in SUBJECTS if s != test]
        Xtr = np.concatenate([by[s][0] for s in train], axis=0)
        ytr = np.concatenate([by[s][1] for s in train], axis=0)
        Xte, yte = by[test]

        pipe = make_pipe(n_components=N_COMPONENTS, standardize=standardize)
        pipe.fit(Xtr, ytr)          # scaler 随 Pipeline 只在这步学均值/方差
        yp = pipe.predict(Xte)      # 测试者只 transform+predict

        label = "standardize" if standardize else "no_standardize"
        rows.append({
            "experiment": EXPERIMENT,
            "n_components": N_COMPONENTS,
            "test_subject": test,
            "n_test_trials": len(yte),
            "accuracy": accuracy_score(yte, yp),
            "macro_f1": f1_score(yte, yp, average="macro"),
            "cohen_kappa": cohen_kappa_score(yte, yp),
            "model": "CSP+Scaler+LDA" if standardize else "CSP+LDA",
            "source": "T session",
            "data_version": "BCICIV_2a_gdf A01T-A09T",
            "note": "standardize=" + label + "，其余锁死(n=6,22ch)",
        })
        print(f"  {label:>14} | test {test}: "
              f"Acc={rows[-1]['accuracy']:.2%}")
    return rows


def main():
    print("=" * 72)
    print(f"优化实验②复核@22ch：仅训练集拟合的标准化（n_components={N_COMPONENTS} 锁死）")
    print("=" * 72)
    by = load_all()

    per_cfg = {}
    all_rows = []
    for label, std in CONFIGS:
        print(f"--- {label} ---")
        rows = loso_rows(by, std)
        per_cfg[label] = {r["test_subject"]: r for r in rows}
        all_rows.extend(rows)

    # ---- 追加进主对比表 model_comparison.csv ----
    comp_csv = os.path.join(ROOT, "results", "model_comparison.csv")
    with open(comp_csv, "a", newline="", encoding="utf-8-sig") as f:
        # 文件已有 header（优化① 22ch 版生成），只追加行；若为空则补写 header
        f.seek(0, os.SEEK_END)
        w = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if f.tell() == 0:
            w.writeheader()
        w.writerows(all_rows)
    print(f"已追加 {len(all_rows)} 行到主对比表: {comp_csv}")

    # ---- 汇总 ----
    base = per_cfg["no_standardize"]
    new = per_cfg["standardize"]
    base_acc = [base[s]["accuracy"] for s in SUBJECTS]
    new_acc = [new[s]["accuracy"] for s in SUBJECTS]
    m_base, s_base = float(np.mean(base_acc)), float(np.std(base_acc))
    m_new, s_new = float(np.mean(new_acc)), float(np.std(new_acc))
    print("-" * 72)
    print(f"no_standardize: LOSO Acc = {m_base:.2%} ± {s_base:.2%}")
    print(f"standardize   : LOSO Acc = {m_new:.2%} ± {s_new:.2%}")
    print(f"差值           : {m_new - m_base:+.2%}（正=加标准化有帮助）")

    sum_csv = os.path.join(ROOT, "results", "standardization_summary.csv")
    with open(sum_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["test_subject", "no_standardize_acc", "standardize_acc", "diff"])
        for s in SUBJECTS:
            d = new[s]["accuracy"] - base[s]["accuracy"]
            w.writerow([s, f"{base[s]['accuracy']:.4f}",
                        f"{new[s]['accuracy']:.4f}", f"{d:+.4f}"])
        w.writerow(["MEAN", f"{m_base:.4f}", f"{m_new:.4f}", f"{m_new - m_base:+.4f}"])
        w.writerow(["STD", f"{s_base:.4f}", f"{s_new:.4f}", ""])
    print(f"逐受试者摘要表已保存: {sum_csv}")

    # ---- 图：逐受试者并排柱状图 ----
    x = np.arange(len(SUBJECTS))
    wd = 0.38
    fig, ax = plt.subplots(figsize=(10, 5.5))
    ax.bar(x - wd / 2, base_acc, wd, label="无标准化(基线)", color="#9AA5B1")
    ax.bar(x + wd / 2, new_acc, wd, label="仅训练集标准化", color="#4C72B0")
    for i, (bv, nv) in enumerate(zip(base_acc, new_acc)):
        sign = "▲" if nv > bv else ("▼" if nv < bv else "=")
        ax.text(i + wd / 2, nv + 0.008, sign, ha="center", va="bottom", fontsize=8)
    ax.axhline(0.25, color="gray", ls=":", lw=1, label="随机基线 25%")
    ax.set_xticks(x)
    ax.set_xticklabels(SUBJECTS)
    ax.set_ylabel("LOSO 准确率")
    ax.set_ylim(0, 0.85)
    ax.set_title("优化②复核：仅训练集拟合的标准化 — 逐受试者 n=6 @22ch 前后对比")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    ax.text(0.01, 0.93,
            f"无标准化 {m_base:.1%}±{s_base:.1%}  →  加标准化 {m_new:.1%}±{s_new:.1%} "
            f"({m_new - m_base:+.1%})",
            transform=ax.transAxes, fontsize=9,
            bbox=dict(boxstyle="round", fc="#F2F2F2", ec="#888888"))
    plt.tight_layout()
    png = os.path.join(ROOT, "results", "standardization_plot.png")
    plt.savefig(png, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"对比图已保存: {png}")


if __name__ == "__main__":
    main()
