"""Multi-subject BCI Competition IV Dataset 2a T-session loader —— 成员C cue 对齐版。

基于成员B multi_subject_data.py 的唯一改动：epoch 锚点从 768(试次起点) 改为 769-772(类别 cue)。
理由：运动想象发生在 cue 之后（标准范式），earlier 以 768 锚定会把窗口前置 2s 到休息期。

Output contract:
    X: (n_trials, 22, n_times), float32
    y: (n_trials,), int64; Left=0, Right=1, Feet=2, Tongue=3
    subject_id: (n_trials,), strings such as A01

Dataset 2a event detail:
- 768 marks trial onset; 769/770/771/772 mark the class cue ~2 s later.
- 本版 epochs 锚定到 769-772（cue），不是 768。
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Iterable, Optional, Sequence

import mne
import numpy as np

EVENT_TO_LABEL = {"769": 0, "770": 1, "771": 2, "772": 3}
LABEL_NAMES = {0: "Left", 1: "Right", 2: "Feet", 3: "Tongue"}
TRIAL_START_CODE = "768"


def _description_to_code(description: str) -> str:
    value = str(description).strip()
    match = re.search(r"(?:^|\D)(768|769|770|771|772)(?:\D|$)", value)
    return match.group(1) if match else value


def find_training_file(data_dir: str | Path, subject_id: str) -> Path:
    root = Path(data_dir).expanduser()
    if not root.exists():
        raise FileNotFoundError(f"Data directory does not exist: {root}")
    sid = subject_id.upper()
    if not re.fullmatch(r"A0[1-9]", sid):
        raise ValueError(f"Invalid subject_id {subject_id!r}; expected A01...A09")
    candidates = sorted(set(
        list(root.rglob(f"{sid}T*.gdf")) +
        list(root.rglob(f"{sid}t*.gdf"))
    ))
    if not candidates:
        raise FileNotFoundError(f"Cannot find {sid}T.gdf under {root}")
    if len(candidates) > 1:
        raise RuntimeError(f"Multiple files found for {sid}: {candidates}")
    return candidates[0]


def _make_labeled_trial_events(raw: mne.io.BaseRaw) -> tuple[np.ndarray, dict[str, int], dict]:
    """Pair each 768 trial-onset marker with the subsequent 769-772 class cue."""
    if len(raw.annotations) == 0:
        raise ValueError("No GDF annotations found.")
    events, event_id = mne.events_from_annotations(raw, verbose="ERROR")
    id_to_desc = {v: str(k) for k, v in event_id.items()}
    parsed = [(int(sample), _description_to_code(id_to_desc[int(code)]))
              for sample, _, code in events]
    parsed.sort(key=lambda item: item[0])

    trial_starts = [i for i, (_, code) in enumerate(parsed) if code == TRIAL_START_CODE]
    labeled_events = []
    label_event_id = {"Left": 1, "Right": 2, "Feet": 3, "Tongue": 4}
    label_code_to_name = {v: k for k, v in label_event_id.items()}
    counts = {name: 0 for name in label_event_id}

    for pos, idx in enumerate(trial_starts):
        start_sample = parsed[idx][0]
        stop_sample = parsed[trial_starts[pos + 1]][0] if pos + 1 < len(trial_starts) else raw.n_times
        cues = [
            (sample, code) for sample, code in parsed[idx + 1:]
            if sample < stop_sample and code in EVENT_TO_LABEL
        ]
        if len(cues) != 1:
            raise ValueError(
                f"Trial at sample {start_sample}: expected exactly one class cue "
                f"(769-772) before next trial, found {[c for _, c in cues]}"
            )
        cue_sample, code = cues[0]
        label = EVENT_TO_LABEL[code]
        name = LABEL_NAMES[label]
        labeled_events.append([cue_sample, 0, label_event_id[name]])  # 锚定 cue，非 768
        counts[name] += 1

    if not labeled_events:
        raise ValueError("No 768 trial-onset markers were found.")
    synthetic_events = np.asarray(labeled_events, dtype=int)
    return synthetic_events, label_event_id, {
        "n_trial_start_markers": len(trial_starts),
        "class_counts": counts,
        "original_event_descriptions": sorted(set(code for _, code in parsed)),
        "epoch_anchor": "cue(769-772)",
    }


def load_subject(
    data_dir: str | Path,
    subject_id: str,
    *,
    l_freq: float = 8.0,
    h_freq: float = 30.0,
    tmin: float = 0.5,
    tmax: float = 3.5,
    expected_sfreq: float = 250.0,
    expected_eeg_channels: int = 22,
    channel_names: Optional[Sequence[str]] = None,
    verbose: str | bool = "ERROR",
):
    """Load one T-session file and return X, y, subject_id, channels, sfreq, metadata."""
    file_path = find_training_file(data_dir, subject_id)
    raw = mne.io.read_raw_gdf(str(file_path), preload=True, verbose=verbose)
    sfreq = float(raw.info["sfreq"])
    if not np.isclose(sfreq, expected_sfreq):
        raise ValueError(f"{subject_id}: {sfreq:g} Hz found; expected {expected_sfreq:g} Hz")

    # MNE currently labels the three EOG channels as EEG for these GDF files.
    # Use the dataset channel-name convention to explicitly select only EEG-*.
    eeg_names = [name for name in raw.ch_names if name.startswith("EEG-")]
    if len(eeg_names) != expected_eeg_channels:
        raise ValueError(
            f"{subject_id}: expected {expected_eeg_channels} EEG-* channels, "
            f"found {len(eeg_names)}: {eeg_names}"
        )
    if channel_names is not None:
        if set(eeg_names) != set(channel_names):
            raise ValueError(
                f"{subject_id}: EEG channel set differs from reference. "
                f"Missing={sorted(set(channel_names)-set(eeg_names))}; "
                f"extra={sorted(set(eeg_names)-set(channel_names))}"
            )
        eeg_names = list(channel_names)

    raw.pick_channels(eeg_names, ordered=True)
    # 对齐成员C 正式口径：8-30 Hz IIR 带通（成员B 原版用 mne 默认 FIR，属另一口径差异）
    raw.filter(l_freq=l_freq, h_freq=h_freq, picks=eeg_names, method="iir", verbose=verbose)

    synthetic_events, label_event_id, event_metadata = _make_labeled_trial_events(raw)
    epochs = mne.Epochs(
        raw,
        synthetic_events,
        event_id=label_event_id,
        tmin=tmin,
        tmax=tmax,
        baseline=None,
        picks=eeg_names,
        preload=True,
        reject_by_annotation=False,   # 对齐 temp_loader 默认，避免行为分叉
        event_repeated="merge",       # 对齐 temp_loader
        verbose=verbose,
    )

    label_from_event = {label_event_id[name]: label for label, name in LABEL_NAMES.items()}
    y = np.asarray([label_from_event[int(code)] for code in epochs.events[:, 2]], dtype=np.int64)
    X = epochs.get_data(copy=True).astype(np.float32, copy=False)
    ids = np.full(len(y), subject_id.upper(), dtype="<U3")

    metadata = {
        "file": str(file_path),
        "sfreq_hz": sfreq,
        "channels": eeg_names,
        "n_eog_channels_excluded": 3,
        "tmin_s": tmin,
        "tmax_s": tmax,
        "n_times": int(X.shape[-1]) if X.ndim == 3 else None,
        "event_metadata": event_metadata,
    }
    if X.ndim != 3 or X.shape[0] != len(y) or X.shape[1] != len(eeg_names):
        raise RuntimeError(f"{subject_id}: invalid output shapes X={X.shape}, y={y.shape}")
    return X, y, ids, eeg_names, sfreq, metadata


def load_multiple_subjects(
    data_dir: str | Path,
    subject_ids: Iterable[str] = tuple(f"A{i:02d}" for i in range(1, 10)),
    **preprocess_kwargs,
):
    subject_ids = [sid.upper() for sid in subject_ids]
    if not subject_ids:
        raise ValueError("subject_ids cannot be empty")
    xs, ys, ids = [], [], []
    reference_channels = None
    reference_sfreq = None
    for sid in subject_ids:
        X, y, sid_array, channels, sfreq, _ = load_subject(
            data_dir, sid, channel_names=reference_channels, **preprocess_kwargs
        )
        if reference_channels is None:
            reference_channels, reference_sfreq = channels, sfreq
        elif channels != reference_channels or not np.isclose(sfreq, reference_sfreq):
            raise ValueError(f"{sid}: channel order or sampling rate differs")
        xs.append(X)
        ys.append(y)
        ids.append(sid_array)
    return np.concatenate(xs), np.concatenate(ys), np.concatenate(ids)


def select_subjects(X, y, subject_id, include=None, exclude=None):
    if len(X) != len(y) or len(y) != len(subject_id):
        raise ValueError("X, y and subject_id must have aligned trial counts")
    mask = np.ones(len(y), dtype=bool)
    if include is not None:
        mask &= np.isin(subject_id, [str(s).upper() for s in include])
    if exclude is not None:
        mask &= ~np.isin(subject_id, [str(s).upper() for s in exclude])
    return X[mask], y[mask], subject_id[mask]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--subjects", nargs="+", default=[f"A{i:02d}" for i in range(1, 10)])
    parser.add_argument("--output", default="results/all_subjects_T.npz")
    args = parser.parse_args()
    X, y, subject_id = load_multiple_subjects(args.data_dir, args.subjects)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out, X=X, y=y, subject_id=subject_id)
    print(f"Saved {out}: X={X.shape}, y={y.shape}, subject_id={subject_id.shape}")


if __name__ == "__main__":
    main()
