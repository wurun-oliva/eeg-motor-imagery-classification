# -*- coding: utf-8 -*-
"""
成员 C · 跨用户模型：多人合并训练基线（复用第一阶段 CSP + LDA）

接口约定（与任务书 §3.2 一致）：
    model.fit(X_train, y_train)
    predictions = model.predict(X_batch)

红线：CSP、LDA 等所有需要学习的步骤都只允许在训练集上 fit；
测试数据（陌生的受试者）只能 transform + predict，绝不允许 fit。
"""
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from mne.decoding import CSP


def make_pipe(n_components: int = 4, reg=None,
              log: bool = True, cov_est: str = "concat",
              standardize: bool = False):
    """构建 CSP(+标准化的)LDA 的 sklearn Pipeline

    参数与第一阶段基线完全一致（n_components=4, reg=None, log=True,
    cov_est="concat"），保证跨用户数字能和单人基线对齐着看。
    后续优化实验从这里把参数透传进来即可（一次只改一个旋钮）。

    standardize=True 会在 CSP 与 LDA 之间插入 StandardScaler（Z-Score），
    用于抹平不同受试者脑电幅值/能量量级的差异。
    红线：scaler 也必须只在训练受试者上 fit——sklearn Pipeline 天然如此
    （fit 时对训练数据做 fit，predict 对测试数据只 transform），
    绝不允许用全体/含测试者的统计量做标准化。

    说明：CSP+LDA 本身没有随机性，可复现性来自固定的数据划分与参数；
    将来若接入带随机性的模型（如 EEGNet），再在调用处固定 random_state。
    """
    csp = CSP(n_components=n_components, reg=reg, log=log, cov_est=cov_est)
    lda = LinearDiscriminantAnalysis()
    steps = [("csp", csp)]
    if standardize:
        steps.append(("scaler", StandardScaler()))
    steps.append(("lda", lda))
    return Pipeline(steps)


def predict_only(pipeline, X_batch):
    """只对测试数据做预测（不触发任何 fit）"""
    return pipeline.predict(X_batch)


if __name__ == "__main__":
    # 最小自检：构造一份假的 4 类数据，验证接口能跑通。
    import numpy as np
    rng = np.random.default_rng(0)
    X = rng.standard_normal((80, 22, 751))
    y = np.arange(80) % 4
    pipe = make_pipe()
    pipe.fit(X[:60], y[:60])
    pred = pipe.predict(X[60:])
    print("cross_subject_model 自检通过：", sorted(set(pred.tolist())))