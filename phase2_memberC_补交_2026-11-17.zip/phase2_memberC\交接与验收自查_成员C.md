# 成员C · 交接与验收自查（22ch 最终版，2026-11-12）

## 1. 交付物对照表（按组长清单）

| 清单项 | 文件 | 状态 |
|---|---|---|
| 代码：跨受试者模型 | `src/models/cross_subject_model.py`（CSP+LDA，make_pipe） | ✅ 已有 |
| 代码：LOSO 评估 | `src/evaluation/loso_evaluation.py` | ✅ 已有，已切正式加载器 |
| 结果：模型对比表 | `results/model_comparison.csv` | ✅ 72 行（成分数36 + 标准化18 + 频带18） |
| 结果：逐受试者 | `results/loso_results_22ch.csv` | ✅ 9 人各一行 + 均值行 |
| 结果：混淆矩阵 | `results/loso_results_22ch_confusion.png` | ✅ |
| 报告：实验记录 | `实验记录_成员C_LOSO与优化_22ch.md` | ✅ |
| 一键可重复运行 | `experiments/cross_subject_experiments/run_all.py` | ✅ 新增 |
| 验收断言 | 内置在 run_all.py（--check-only 默认） | ✅ 新增 |

## 2. 验收标准自答（可复现验证）

### ① 测试受试者不参与训练/模型选择/任何拟合 —— ✅ 通过
LOSO（留一受试者法）：每轮 `test_subject` 不在 `train_subjects` 里，训练恒 8 人；
CSP、LDA、标准化全部只在 train 上 fit，test 只变换。
自动断言：`python experiments/cross_subject_experiments/run_all.py`（无参数）输出“验收断言：全部通过”。

### ② 每名测试用户都有独立结果 —— ✅ 通过
A01..A09 共 9 行，`test_subject` 全覆盖且无重复（断言内部检查）。

### ③ 实验可重复运行 —— ✅ 提供一键幂等重跑
`python experiments/cross_subject_experiments/run_all.py --rerun`：先清空对比表（避免重复行）→ 按序跑基线/成分数/标准化/频带 4 个实验 → 自动对账 72 行与自检。
全部脚本固定 `random_state=42`，CSP-log 拼接 + LDA 为确定性算法；数据侧固定 22 通道顺序、8-30 Hz IIR、epoch 0.5-3.5 s。

## 3. 重大发现：成员B 加载器存在两处口径差异（需合入上游前修正）

### 差异一：epoch 事件锚点（最关键）
- 成员B 原版 `multi_subject_data.py`：anchored to **768（试次起始）**。
- 本组验收口径：anchored to **769-772（类别 cue）**，取 cue 后 0.5-3.5 s —— 运动想象发生在 cue 之后。
- 实测：A01 的 768→cue 间隔恒为 **500 个采样点 = 2.000 s**（288/288 全部），两版本窗口整体错开 2 s。
- 影响：同一模型精度 39.58% → 29.1%（锚 768 把休息期当成了想象窗口）。

### 差异二：带通滤波方法
- 成员B 原版：`raw.filter(...)` 默认 mne **FIR**。
- 本组验收口径：**IIR**（Butterworth two-pass，规范 §4.2 约定）。
- 影响：波形非逐位一致；两者都可用，但必须统一口径，否则跑出来的数字对不上。

### 给成员B 的修正单
1. `load_subject` 增加锚点参数（如 `anchor="cue"` 默认），epoch 事件用 769-772 cue 样本，并更新 docstring“Epochs are anchored to 768”这句。
2. `raw.filter` 显式传 `method="iir"`，或在预处理说明里明确 FIR；与其它成员统一。
3. 建议把 `load_subject` 的默认 `tmin/tmax` 明确写进 README（0.5-3.5 s 相对 cue）。

## 4. 加载器交接状态

正式链路已切换：`loso_evaluation.py` 与 3 个优化实验均改从 `src/data/data_loader.py` 取 `load_trials`；
胶水委托 `multi_subject_data_cue.py`（= 成员B 代码 + 上述两处口径修正）。
对账证据：
- A01：shape (288,22,751)/4 类×72/通道顺序，与原 `temp_loader` 一致；
- 9 人 LOSO 基线逐位复现原值（平均 39.58%），whole-array 最大差 1.8e-12（纯 float32 舍入）。

## 5. 关键结果速览（22ch 验收口径）

- 基线 n=4：Acc 39.58% ± 12.42 | MacroF1 0.3490 ± 0.141 | Kappa 0.1944 ± 0.166
- 最优 CSP 成分数 **n=6**：41.98% ± 15.47
- 标准化：n=6 两档逐位 +0.00%（不引入）
- 频带：8-30Hz = 41.98%（最优）；4-38Hz = 40.32%（-1.66pp，不采用）
- 结论：n=6、8-30Hz、不标准化、约 **42.0%**
- 个体差异明显（A06 低至 22%/Kappa 为负），报告已如实注明。

## 6. 遗留待办
- [ ] 成员B 完成复现自检（npz/质量报告）后，回传其 `multi_subject_data.py` 修正版；本组复核一遍即可。
- [ ] 建 git 仓库补 `commit ID`（实验记录附录 A 字段）。
- [ ] （可选）Riemannian / EEGNet 对照需装依赖，未做。
