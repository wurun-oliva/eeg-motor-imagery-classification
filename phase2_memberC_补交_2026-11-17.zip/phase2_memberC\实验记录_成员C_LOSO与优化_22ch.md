# 实验记录 · 成员 C：跨用户（LOSO）模型训练与三项优化

> 口径：22 个头皮 EEG 通道；**2026-11-17 起全部数字按“成员B 官方加载器修正版 + 显式 IIR Butterworth order=8”口径**（此前 39.58%/41.98% 为 mne 默认自动阶数版，已作废）。

## 0. 元信息

| 字段 | 内容 |
|---|---|
| 实验名称 | 跨用户运动想象分类：LOSO 基线 + CSP 成分数扫描 + 标准化 + 滤波频带 |
| 负责人 | 成员 C（算法研究与改进实验） |
| 日期 | 2026-11-12 首版；**2026-11-17 全量重跑（显式 order=8 口径）** |
| 数据集 | BCI Competition IV 2a（A01–A09，共 9 人），训练 session（T） |
| 数据文件 | `data/BCICIV_2a_gdf/A*T.gdf` |
| 加载器 | 成员B 官方 `src/data/multi_subject_data.py`（锚点=类别 cue 769-772；`iir_params=dict(order=8, ftype="butter")`；22 通道固定顺序；经 `data_loader.py` 胶水校验） |
| 场景 | 每受试者 288 trial（每类 72），9 人一致 |
| Git commit ID | **暂无**（BCI2a_repro 尚未 git init）。临时以 SHA-256 指纹做可追溯，见附录 A |
| 复现命令 | 见附录 B（一键 `run_all.py --rerun`） |

## 1. 数据集与受试者范围；各受试者 trial 数量与类别分布

- 受试者：A01–A09 全部 9 人；每受试者 T session 均 **288 trial**，类别完全平衡：左手(0)/右手(1)/双脚(2)/舌头(3) 各 **72**。
- 实测：`X.shape = (288, 22, 751)`（每受试者），`n_test_trials` 全为 288；B 官方加载器与临时 cue 版全 9 人逐位一致（max|Δ|=0.0）。

## 2. 预处理设置

| 项 | 设置 | 说明 |
|---|---|---|
| 通道 | **22 个头皮 EEG，顺序显式固定**（`data_loader.DEFAULT_EEG_CHANNELS`） | gdf 原始 25 通道剔除 3 个 EOG；mne 将 EOG 读作 `eeg` 类型无法按类型过滤，故按名单固定顺序 |
| 采样率 | 250 Hz（未重采样） | |
| 滤波 | **IIR Butterworth 带通 8–30 Hz，显式 order=8，两通零相位（有效 16 阶）** | `method="iir", iir_params=dict(order=8, ftype="butter"), phase="zero"`；与实时端 SOS（order=8，`butter(8,[8,30],'bandpass',fs=250,output='sos') → (8,6)`）**同一组系数**，两端特征完全对齐。频带实验单独改 4–38 Hz |
| Epoch | 事件后 0.5–3.5 s（含端点，**751 点**） | `tmin=0.5, tmax=3.5, baseline=None` |
| 事件锚定 | **类别 cue（769→0/770→1/771→2/772→3）** | `anchor="cue"`；B 原版锚 768（试次起点）会使窗口前置 2 s，已由 B 修正单落实改为 cue |

## 3. 模型结构与参数

Pipeline（scikit-learn）：`CSP(log=True, n_components, reg=None, cov_est=concat) → [StandardScaler?] → LinearDiscriminantAnalysis`

| 超参 | 值 |
|---|---|
| CSP 成分数 | 各实验见其章节；**新基准 = 6** |
| 正则 / log | `reg=None` / `log=True` |
| 协方差估计 | `cov_est=concat`（跨类别合并估计） |
| 标准化 | 实验 3 的对比项 `standardize True/False`，其余实验不启用 |
| 随机种子 | 42 |
| 分类器 | LDA（无 shrinkage） |

## 4. 训练 / 验证 / 测试划分

- 协议：**LOSO（留一受试者出）**：每轮完整留出 1 人当测试，其余 8 人训练；共 9 轮，每轮只评估留出者。
- 测试受试者数据**不参与**训练 / 特征选择 / 标准化拟合 / 超参选择（全流程遵守，无泄漏；验收断言核实训练人数=8、9 行独立）。
- 标准化（若启用）随 Pipeline 仅在训练集 fit，测试集只 `transform+predict`。
- 每轮训练 8×288 = 2304 trial，测试 288 trial。

## 5. 评价指标

- Accuracy（总体正确率）、Macro-F1（4 类宏平均）、Cohen's Kappa；汇总为 9 轮均值 ± 标准差。
- 随机基线 = 25%。
- 混淆矩阵：`loso_results_22ch_confusion.png`（总体汇总，CSP+LDA n=4 基线）。

## 6. 实验 1：LOSO 基线（22ch，n=4，8–30 Hz）

来源：`loso_results_22ch.csv`（`--n-components 4 --seed 42`）

| 受试者 | Acc (%) | Macro-F1 | Kappa |
|---|---|---|---|
| A01 | 55.90 | 0.4810 | 0.4120 |
| A02 | 27.08 | 0.2364 | 0.0278 |
| A03 | 58.68 | 0.5733 | 0.4491 |
| A04 | 32.99 | 0.2153 | 0.1065 |
| A05 | 26.04 | 0.2003 | 0.0139 |
| A06 | 22.57 | 0.1684 | -0.0324 |
| A07 | 33.33 | 0.2822 | 0.1111 |
| A08 | 57.29 | 0.5703 | 0.4306 |
| A09 | 52.08 | 0.5127 | 0.3611 |
| **平均 ± 标准差** | **40.66 ± 14.15** | 0.3600 ± 0.1703 | 0.2088 ± 0.2001 |

结论：跨用户明显低于单受试者场景（单人多分类基线约 60%），难在脑电个体差异而非算法失灵；A06 低于随机、A02/A05 贴近随机，属困难受试者。

## 7. 实验 2：CSP 成分数扫描（22ch，8–30 Hz，LOSO）

来源：`csp_components_summary.csv`（只改 `n_components`）

| 成分数 | 平均 Acc ± std | 备注 |
|---|---|---|
| 2 | 36.38 ± 10.09 | |
| 4（基线档） | 40.66 ± 14.15 | |
| **6** | **42.01 ± 15.28** | ← **最优（较 n=4 +1.35pp）** |
| 8 | 40.86 ± 15.18 | |

n=6 逐人 Acc(%)：A01 53.82 / A02 25.00 / A03 57.99 / A04 36.81 / A05 27.08 / A06 23.96 / A07 34.03 / A08 **68.40** / A09 51.04。

结论：n=6 平均最优，增益主要来自本已较强的 A08/A03；困难受试者（A02/A05/A06）无改善且波动变大 → 定 **n=6 为新基准**。

## 8. 实验 3：仅训练集拟合的标准化（22ch，n=6 锁死）

来源：`standardization_summary.csv`

| 档位 | 平均 Acc ± std |
|---|---|
| 无标准化 | 42.01 ± 15.28 |
| 仅训练集标准化 | 42.01 ± 15.28 |

**9 人逐位数字完全一致，差值 +0.00%**。原因（数学性质，非 bug）：StandardScaler 是逐维可逆线性变换，LDA 决策只依赖样本间相对关系，对该类整体缩放免疫。

结论：CSP+LDA 组合下该旋钮无效，**不调**；换对尺度敏感的分类器（SVM / 神经网络 EEGNet）后必须重新评估——已计入答辩 Q&A。

## 9. 实验 4：滤波频带（22ch，n=6 锁死）

来源：`band_summary.csv`；自检：8–30 档与实验 2 的 n=6 逐位一致（验收断言③）

| 频带 | 平均 Acc ± std | vs 8–30 |
|---|---|---|
| **8–30 Hz（基线 / 经典）** | **42.01 ± 15.28** | — |
| 4–38 Hz（宽频带） | 40.12 ± 16.79 | **-1.89pp** |

4–38 逐人 Acc(%)：A01 46.88 / A02 24.65 / A03 62.15 / A04 35.42 / A05 23.96 / A06 25.00 / A07 **22.92** / A08 69.10 / A09 51.04。

结论：宽频带无益；多放行的 4–8 / 30–38 Hz 多为噪声，放大困难受试者的不稳定（A07 -11.1pp、A01 -6.9pp）→ **维持 8–30 Hz**。

## 10. 汇总

- 统一对比表：`model_comparison.csv`（**72 行 = 成分数 36 + 标准化 18 + 频带 18**，均为 22ch 口径、含逐受试者指标）。
- 本阶段主结论（22ch，CSP+LDA / LOSO）：**成分数 n=6、频带 8–30 Hz、不启用标准化 → 平均准确率 42.01%**（±15.28）。
- 训练端滤波已显式 order=8（= 实时接口规范中的 SOS 系数组），2026-11-17 全量重跑确认三处优化结论不变。
- 交付物：部署模型 `bci2a_csp_lda_n6_all9.joblib`（全 9 人 2592 trial 合并训练，n=6）、实时系数 `realtime_sos_butter8_8-30_250.npy/.json`、通道清单 `channels_order.json`、给 A 的《实时接口规范_v1_给A.md》、给 B 的《给成员B_加载器修正单.md》。

## 附录 A：代码版本指纹（git 前的临时可追溯）

| 文件 | SHA-256（前 12 位） |
|---|---|
| `src/data/data_loader.py` | AB6F88E9A7B1 |
| `src/data/multi_subject_data.py`（B 官方修正版） | B144D8BF3ABC |
| `experiments/cross_subject_experiments/run_all.py` | 07EF574B4A07 |
| `src/deployment/train_export_model.py` | DF3D20E4D80D |
| `src/deployment/predict_deploy.py` | 236282EAD622 |
| `src/deployment/realtime_filter_spec.py` | 1E806A7BB4C0 |
| `src/evaluation/loso_evaluation.py` | 535811FAF7BD |
| `experiments/cross_subject_experiments/csp_components_scan.py` | 5F4F95560356 |
| `experiments/cross_subject_experiments/standardization_scan_22ch.py` | 09B245757013 |
| `experiments/cross_subject_experiments/band_scan_22ch.py` | C9301517D7E4 |

## 附录 B：复现命令（cwd=`BCI2a_repro/`，Python 3.13 / mne 1.13 / scikit-learn 1.9）

```text
# 一键全量（清表→按序重跑 4 实验→对账断言；commit 用）
python experiments/cross_subject_experiments/run_all.py --rerun

# 等价分步：
# 1) LOSO 基线（22ch, n=4, 8-30Hz）
python src/evaluation/loso_evaluation.py --subjects A01 A02 A03 A04 A05 A06 A07 A08 A09 --out results/loso_results_22ch.csv --n-components 4 --seed 42
# 2) CSP 成分数扫描（2/4/6/8）
python experiments/cross_subject_experiments/csp_components_scan.py
# 3) 标准化复核（n=6）
python experiments/cross_subject_experiments/standardization_scan_22ch.py
# 4) 频带复核（8-30 vs 4-38）
python experiments/cross_subject_experiments/band_scan_22ch.py
# 5) 部署模型（n=6 全 9 人合并训练）
python src/deployment/train_export_model.py
# 6) 实时系数/通道清单导出（规范化、可自检）
python src/deployment/realtime_filter_spec.py
```

## 附录 C：已知缺口 / 待办

- [ ] Git commit ID 缺失 → 待建立仓库后补填；临时见附录 A 指纹。
- [x] 加载器替换：已切到成员B 官方加载器（原 `temp_loader` 已不用于正式链路）。
- [x] 滤波显式化：训练端 = 实时端 = order=8（2026-11-17，团队决策）。
- [ ] 给 B 同步“差异③：显式 iir_params(order=8)”到其正式加载器并回传复核。
- [ ] 可选后续：Riemannian Alignment / EEGNet（当前环境 `pyriemann`/`torch`/`tensorflow` 均未安装）。
