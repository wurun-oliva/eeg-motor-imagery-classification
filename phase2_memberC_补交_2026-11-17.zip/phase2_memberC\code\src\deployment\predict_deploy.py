# -*- coding: utf-8 -*-
"""加载部署模型并对外预测。成员A 实时接口可直接 import 本工具或对照示例。

用法：
  python src/deployment/predict_deploy.py \
      --model outputs/phase2_memberC/bci2a_csp_lda_n6_all9.joblib \
      --npz <某.npz 或 .npy，形状 (N,22,751) float32/float64>
  不带 --npz 时用 A01 前 8 个 trial 演示。

输出：每行 <label(0-3)> <prob0 prob1 prob2 prob3>；0=左手 1=右手 2=双脚 3=舌头
"""
import argparse
import os
import sys

import numpy as np
import joblib

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

CLASS_NAMES = {0: "Left/左手", 1: "Right/右手", 2: "Feet/双脚", 3: "Tongue/舌头"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model",
                    default="outputs/phase2_memberC/bci2a_csp_lda_n6_all9.joblib")
    ap.add_argument("--npz", default=None,
                    help="(N,22,751) 数组文件，仅支持单个数组")
    ap.add_argument("--data-dir", default="data/BCICIV_2a_gdf")
    args = ap.parse_args()

    pipe = joblib.load(args.model)
    if args.npz is not None:
        a = np.load(args.npz, allow_pickle=True)
        if isinstance(a, np.lib.npyio.NpzFile):
            key = a.files[0] if len(a.files) == 1 else "arr_0"
            X = np.asarray(a[key], dtype=np.float32)
        else:
            X = np.asarray(a, dtype=np.float32)
    else:
        from src.data.data_loader import load_trials
        X, _, _ = load_trials(os.path.join(args.data_dir, "A01T.gdf"), "A01")
        X = X[:8]

    if X.ndim != 3 or X.shape[1:] != (22, 751):
        raise SystemExit(f"输入形状应是 (N,22,751)，实际 {X.shape}")
    pred = pipe.predict(X)
    proba = pipe.predict_proba(X)
    print(f"输入 {X.shape}  → 输出 {pred.shape}")
    for i in range(len(pred)):
        line = "  ".join(f"{p:.3f}" for p in proba[i])
        print(f"[{i}] 预测={pred[i]} ({CLASS_NAMES[pred[i]]})   proba: {line}")


if __name__ == "__main__":
    main()
