# -*- coding: utf-8 -*-
"""
成员C · 优化实验③复核@22ch：滤波频带（一次只改频带，n_components=6 新基准）

· 新基准：把成分数扫描@22ch 的最优 n_components=6 定为后续所有实验默认成分数。
· 候选频带：8-30Hz（基线/经典 mu+beta） vs 4-38Hz（宽频带，补进 delta/theta 与高 beta）。
· 其余全部锁死：CSP log=True cov_est=concat、LDA、T session、LOSO 规则。
· 一致性命中：BAND_8-30 这一档应精确等于成分数扫描@22ch 里 n=6 的数字（0.4198），
  作为基准自检。
· 22ch 复核标记：2026-11-12 按规范 §4.2 用 22ch（剔除 EOG、顺序固定）重跑本实验；
  旧版脚本 band_scan.py 保留不动（供 25ch 时代复现），产物已在 results/_archive_25ch/。

产物（追加进 22ch 主对比表）：
  results/model_comparison.csv   （新增 experiment=frequency_band 的 18 行）
  results/band_summary.csv
  results/band_plot.png
"""
import csv
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, f1_score, cohen_kappa_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from src.models.cross_subject_model import make_pipe      # noqa: E402
from src.data.data_loader import load_trials          # noqa: E402（成员B正式加载器胶水）

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SUBJECTS = [f"A0{i}" for i in range(1, 10)]
DATA_DIR = "data/BCICIV_2a_gdf"
N_COMPONENTS = 6                        # 22ch 新基准（成分数扫描@22ch 最优）
BANDS = [                              # (label, l_freq, h_freq)
    ("8-30", 8, 30),
    ("4-38", 4, 38),
]
EXPERIMENT = "frequency_band"
ROOT = os.path.join(os.path.dirname(__file__), "..", "..")

FIELDNAMES = ["experiment", "n_components", "test_subject", "n_test_trials",
              "accuracy", "macro_f1", "cohen_kappa", "model", "source",
              "data_version", "note"]


def load_all(l_freq, h_freq):
    """按给定频带加载 9 名受试者（滤波发生在加载阶段，故每频带各加载一次）。"""
    by = {}
    for s in SUBJECTS:
        X, y, _sid = load_trials(f"{DATA_DIR}/{s}T.gdf", subject_id=s,
                                 l_freq=l_freq, h_freq=h_freq)
        by[s] = (X, y)
    return by


def loso_rows(by, band_label):
    rows = []
    for test in SUBJECTS:
        train = [s for s in SUBJECTS if s != test]
        Xtr = np.concatenate([by[s][0] for s in train], axis=0)
        ytr = np.concatenate([by[s][1] for s in train], axis=0)
        Xte, yte = by[test]

        pipe = make_pipe(n_components=N_COMPONENTS)      # 新基准，其余锁死
        pipe.fit(Xtr, ytr)
        yp = pipe.predict(Xte)

        rows.append({
            "experiment": EXPERIMENT,
            "n_components": N_COMPONENTS,
            "test_subject": test,
            "n_test_trials": len(yte),
            "accuracy": accuracy_score(yte, yp),
            "macro_f1": f1_score(yte, yp, average="macro"),
            "cohen_kappa": cohen_kappa_score(yte, yp),
            "model": "CSP+LDA",
            "source": "T session",
            "data_version": "BCICIV_2a_gdf A01T-A09T",
            "note": f"band={band_label}Hz, n={N_COMPONENTS}(22ch新基准)，只改频带",
        })
        print(f"  band={band_label:>5}Hz | test {test}: Acc={rows[-1]['accuracy']:.2%}")
    return rows


def mean_std(rows, subj):
    accs = [r["accuracy"] for r in rows if r["test_subject"] == subj]
    return accs[0]


def main():
    print("=" * 72)
    print(f"优化实验③复核@22ch：滤波频带（n_components={N_COMPONENTS} 新基准，其余锁死）")
    print("=" * 72)

    per_band = {}
    all_rows = []
    for label, lo, hi in BANDS:
        print(f"--- band={label} Hz ---")
        by = load_all(lo, hi)
        rows = loso_rows(by, label)
        per_band[label] = rows
        all_rows.extend(rows)

    # ---- 追加进主对比表 ----
    comp_csv = os.path.join(ROOT, "results", "model_comparison.csv")
    with open(comp_csv, "a", newline="", encoding="utf-8-sig") as f:
        f.seek(0, os.SEEK_END)
        w = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if f.tell() == 0:
            w.writeheader()
        w.writerows(all_rows)
    print(f"已追加 {len(all_rows)} 行到主对比表: {comp_csv}")

    # ---- 汇总 ----
    res = {label: [r["accuracy"] for r in per_band[label]] for label, _, _ in BANDS}
    stat = {label: (float(np.mean(res[label])), float(np.std(res[label])))
            for label, _, _ in BANDS}
    for label, _, _ in BANDS:
        m, s = stat[label]
        print(f"band={label:>5}Hz: LOSO Acc = {m:.2%} ± {s:.2%}")
    lab0, lab1 = BANDS[0][0], BANDS[1][0]
    d = stat[lab1][0] - stat[lab0][0]
    print("-" * 72)
    print(f"{lab1}Hz vs {lab0}Hz 平均差值: {d:+.2%}（正=宽频带更好）")
    print(f"自检：{lab0}Hz 应精确等于成分数扫描@22ch 里 n=6 的数字（0.4198），若不等要查原因。")

    sum_csv = os.path.join(ROOT, "results", "band_summary.csv")
    with open(sum_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["test_subject", f"{lab0}Hz_acc", f"{lab1}Hz_acc", "diff"])
        for i, s in enumerate(SUBJECTS):
            w.writerow([s, f"{res[lab0][i]:.4f}", f"{res[lab1][i]:.4f}",
                        f"{res[lab1][i] - res[lab0][i]:+.4f}"])
        w.writerow(["MEAN", f"{stat[lab0][0]:.4f}", f"{stat[lab1][0]:.4f}", f"{d:+.4f}"])
        w.writerow(["STD", f"{stat[lab0][1]:.4f}", f"{stat[lab1][1]:.4f}", ""])
    print(f"逐受试者摘要表已保存: {sum_csv}")

    # ---- 图：逐受试者并排柱状图 ----
    x = np.arange(len(SUBJECTS))
    wd = 0.38
    fig, ax = plt.subplots(figsize=(10, 5.5))
    ax.bar(x - wd / 2, res[lab0], wd, label=f"{lab0}Hz (基线)", color="#9AA5B1")
    ax.bar(x + wd / 2, res[lab1], wd, label=f"{lab1}Hz (宽频带)", color="#55A868")
    for i, (bv, nv) in enumerate(zip(res[lab0], res[lab1])):
        sign = "▲" if nv > bv else ("▼" if nv < bv else "=")
        ax.text(i + wd / 2, nv + 0.008, sign, ha="center", va="bottom", fontsize=8)
    ax.axhline(0.25, color="gray", ls=":", lw=1, label="随机基线 25%")
    ax.set_xticks(x)
    ax.set_xticklabels(SUBJECTS)
    ax.set_ylabel("LOSO 准确率")
    ax.set_ylim(0, 0.85)
    ax.set_title(f"优化③复核：滤波频带对比 @22ch（n_components={N_COMPONENTS} 新基准）")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    ax.text(0.01, 0.93,
            f"{lab0}Hz {stat[lab0][0]:.1%}±{stat[lab0][1]:.1%}  →  {lab1}Hz "
            f"{stat[lab1][0]:.1%}±{stat[lab1][1]:.1%} ({d:+.1%})",
            transform=ax.transAxes, fontsize=9,
            bbox=dict(boxstyle="round", fc="#F2F2F2", ec="#888888"))
    plt.tight_layout()
    png = os.path.join(ROOT, "results", "band_plot.png")
    plt.savefig(png, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"对比图已保存: {png}")


if __name__ == "__main__":
    main()
