﻿# 给成员B：加载器修正单（epoch 锚点 + 滤波口径）

致 B：这是成员 C 对接你的 `multi_subject_data.py` 时定位到的两处"口径约定不一致"，不是代码 bug。改一致后，两边数字逐位对齐（LOSO 基线 39.58%）。希望你在下次迭代里合入并发回最新版。

---

## 差异①（关键）：epoch 事件锚点

**现象**：用你的加载器跑 LOSO，基线从本组已验收的 39.58% 掉到 29.1%。

**原因**：两次读取对"事件"的定义不同，切窗整体错开 2 秒。

- 你的版：在 `_make_labeled_trial_events` 中，把每个 trial 的 **768（trial onset）** 当作事件样本 → epoch 0.5–3.5 s 相对 onset。
- 本组口径（规范 §4.2 / 范式）：事件应为 **769–772（class cue）** → epoch 0.5–3.5 s 相对 cue。运动想象发生在 cue 之后，以 768 锚定等于把"提示音前的休息期"当成想象集。

**实测证据（A01）**：原始注解里 768→cue 的间隔**恒为 500 个采样点 = 2.000 s**（288 个 trial 全部精确一致）。所以两版本取到的是错开 2 s 的两段脑电。

**改法（最小改动）**：在 `multi_subject_data.py` 的 `_make_labeled_trial_events` 中，把事件样本从 `start_sample` 换成该 trial 的 cue 样本：

```python
# 现在（锚 768）：
labeled_events.append([start_sample, 0, label_event_id[name]])

# 改为（锚 769-772 cue）：
labeled_events.append([cue_sample, 0, label_event_id[name]])
```

说明：你已有的 `cue_codes` 收集里，每个 trial 恰有一个 cue（769/770/771/772），把变成 `cues = [(sample, code) ...]` 取出 `cue_sample` 即可；label 从该 cue 的 code 映射（`EVENT_TO_LABEL`），与现有逻辑一致。

配套建议：`load_subject` 增加 `anchor="cue"` 参数（默认 `"cue"`，保留 `"onset"` 选项向前兼容），并将文件头 docstring 中 `Epochs are anchored to 768, not to the later class marker` 一句改掉，避免后人再误解。

**现成参考**：成员 C 已 fork 一份 `src/data/multi_subject_data_cue.py`（仅上述锚点 + 下面滤波两处不同），可直接对照 diff。

---

## 差异②：带通滤波方法（FIR vs IIR）

**现象**：即使锚点改对，波形也不逐位一致。

**原因**：你的 `raw.filter(...)` 没传 `method`，用的是 mne 默认 **FIR**；本组验收口径是 **IIR**（Butterworth，双向零相位，规范 §4.2 约定）。

**改法**：显式传 `method="iir"`：

```python
raw.filter(l_freq=l_freq, h_freq=h_freq, picks=eeg_names, method="iir", verbose=verbose)
```

备注：FIR 并非不能用，但全组必须统一一个口径才能对得上数。

---

## 验收（改完你自己跑，或直接对账）

1. A01：`X.shape == (288, 22, 751)`，dtype float32；`np.bincount(y) == [72,72,72,72]`。
2. 采样率 250 Hz；通道恰 22 个 EEG-*；epoch 相对 cue 取 [0.5, 3.5] s。
3. 与成员 C 的 `src/data/multi_subject_data_cue.py` 对账：whole-array `max|X_cue - X_before|` 应为 **≤ 1e-11**（纯 float32 舍入量级，不是 1e-5 这种数值差）。

## 预期结果

以上两处改完，再用你的 `multi_subject_data.py` 跑 LOSO 基线，应与本组已验收口径**逐位一致（39.58%）**。你方顺带完成复现自检（npz / channel quality / 质量报告）并回传最终版后，成员 C 复核一遍即算交接闭环。

---

*附：本单对应的完整对比材料见 `outputs/phase2_memberC/交接与验收自查_成员C.md` 第 3 节。*

---

## 最新进展（2026-11-17）：你的修正版已回传并验收通过

- 锚点 cue、method=iir 均已按本单落实；与成员C 的 cue 对齐版全 9 人逐位一致（max|X||Δ|=0.0；你的 reject_by_annotation=True / event_repeated=error 在 BCI2a 上无实际影响）。
- 还需你合入下方【差异③】并回传正式版。

## 差异③（团队决策 2026-11-17）：显式滤波阶数 order=8

**现象**：method=iir 时 mne 默认会让阶数内部自动调整、系数不透明（本组实证：与显式 order=8 差约 1pp，如 n=4 LOSO 39.58% vs 40.66%），且无法与实时端显式 Butterworth order=8 SOS 逐点对上。

**决策**：全组统一显式 iir_params=dict(order=8, ftype=butter)（两通 -> effective 16，零相位）。训练端与实时端用同一组系数，两端特征完全对齐。

**改法**：将 raw.filter(method=iir, ...) 改为 raw.filter(method=iir, iir_params=dict(order=8, ftype=butter), ...)，metadata filter.order 记 8。

**实证（显式 order=8 口径，成员C 全量重跑）**：LOSO n=4=40.66% | n=6=42.01%；标准化仍免疫(+0.00)；8-30Hz=42.01 vs 4-38=40.12。部署模型已重训。

**验收**：重跑一次 run_all.py --rerun（已修复 loso 段缺 --subjects/--out）-> 断言 ①②③ 全过；或与成员C 交付 zip 内 multi_subject_data.py 逐位对账 max|Δ|<=1e-11。